"""
Registry of bundled DICOM SEG files.

Maps original CT SeriesInstanceUID → bundled SEG filename so the package
can resolve a SEG purely from the CT series it ships with, without the
caller needing to provide the SEG file.
"""

from __future__ import annotations

import json
import shutil
from importlib import resources
from pathlib import Path
from typing import Optional

import pydicom

_REGISTRY_CACHE: dict[str, dict] | None = None
_SEG_SOP_CLASS_UID = "1.2.840.10008.5.1.4.1.1.66.4"


def _data_dir() -> Path:
    """Return the path to the package ``data/`` directory."""
    return Path(__file__).resolve().parent / "data"


def _load_registry() -> dict[str, dict]:
    """Load (and cache) the registry mapping from ``data/registry.json``."""
    global _REGISTRY_CACHE
    if _REGISTRY_CACHE is None:
        registry_path = _data_dir() / "registry.json"
        if registry_path.exists():
            _REGISTRY_CACHE = json.loads(registry_path.read_text())
        else:
            _REGISTRY_CACHE = {}
    return _REGISTRY_CACHE


def _save_registry(registry: dict[str, dict]) -> None:
    """Persist the registry to ``data/registry.json``."""
    global _REGISTRY_CACHE
    registry_path = _data_dir() / "registry.json"
    registry_path.write_text(json.dumps(registry, indent=4) + "\n")
    _REGISTRY_CACHE = registry


def lookup(series_uid: str) -> Optional[Path]:
    """
    Return the path to the bundled SEG file for the given CT
    *series_uid*, or ``None`` if none is registered.
    """
    registry = _load_registry()
    entry = registry.get(series_uid)
    if entry is None:
        return None
    seg_path = _data_dir() / entry["seg_file"]
    return seg_path if seg_path.exists() else None


def lookup_info(series_uid: str) -> Optional[str]:
    """
    Return the exam info text for the given CT *series_uid*,
    or ``None`` if none is stored.
    """
    registry = _load_registry()
    entry = registry.get(series_uid)
    if entry is None:
        return None
    return entry.get("info")


def list_entries() -> dict[str, dict]:
    """Return a copy of the full registry."""
    return dict(_load_registry())


def ingest(seg_path: str | Path, *, info_file: str | Path | None = None) -> str:
    """
    Ingest a DICOM SEG file into the package's bundled data store.

    Reads the SEG, extracts the ``ReferencedSeriesSequence`` to discover
    which CT SeriesInstanceUID it belongs to, copies the file into
    ``data/``, and updates ``registry.json``.

    Parameters
    ----------
    seg_path : str | Path
        Path to a DICOM SEG file on disk.
    info_file : str | Path | None
        Optional path to an ``info.txt`` file describing the exam
        characteristics. Its content will be stored in the registry
        and displayed on ``extract``.

    Returns
    -------
    str
        The CT SeriesInstanceUID that was registered.

    Raises
    ------
    ValueError
        If the file is not a valid DICOM SEG or has no
        ReferencedSeriesSequence.
    """
    seg_path = Path(seg_path).resolve()
    ds = pydicom.dcmread(str(seg_path), force=True)

    # Validate it is a SEG IOD
    sop_class = getattr(ds, "SOPClassUID", None)
    if str(sop_class) != _SEG_SOP_CLASS_UID:
        raise ValueError(
            f"{seg_path.name} is not a DICOM SEG (SOPClassUID={sop_class})"
        )

    # Extract referenced CT series UID
    ref_seq = getattr(ds, "ReferencedSeriesSequence", None)
    if not ref_seq:
        raise ValueError(
            f"{seg_path.name} has no ReferencedSeriesSequence"
        )
    ct_series_uid = str(ref_seq[0].SeriesInstanceUID)

    # Determine a unique filename for storage
    seg_series_uid = str(ds.SeriesInstanceUID)
    dest_filename = f"seg-{ct_series_uid[-16:]}.dcm"
    dest_path = _data_dir() / dest_filename
    shutil.copy2(str(seg_path), str(dest_path))

    # Read optional info file
    info_text: str | None = None
    if info_file is not None:
        info_path = Path(info_file).resolve()
        if info_path.is_file():
            info_text = info_path.read_text(encoding="utf-8").strip()
        else:
            raise FileNotFoundError(f"Info file not found: {info_path}")

    # Update registry
    registry = _load_registry()
    entry: dict = {
        "seg_file": dest_filename,
        "seg_series_uid": seg_series_uid,
        "study_uid": str(getattr(ds, "StudyInstanceUID", "")),
        "description": getattr(ds, "SeriesDescription", ""),
    }
    if info_text is not None:
        entry["info"] = info_text
    registry[ct_series_uid] = entry
    _save_registry(registry)

    return ct_series_uid
