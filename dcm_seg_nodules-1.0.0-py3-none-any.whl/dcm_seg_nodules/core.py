"""Core logic for extracting DICOM SEG IOD matched to a DICOM series."""

from __future__ import annotations

import logging
import shutil
from pathlib import Path
from typing import Optional

import pydicom

from dcm_seg_nodules import registry

logger = logging.getLogger(__name__)


def _read_dicom_safe(filepath: str | Path) -> Optional[pydicom.Dataset]:
    """Read a DICOM file, returning None if the file is not valid DICOM."""
    try:
        return pydicom.dcmread(str(filepath), force=True)
    except Exception:
        return None


def read_series_uid(series_dir: str | Path) -> str:
    """
    Read DICOM files from *series_dir* and return their common
    SeriesInstanceUID.

    Parameters
    ----------
    series_dir : str | Path
        Path to a directory containing DICOM files belonging to a single
        CT series.

    Returns
    -------
    str
        The SeriesInstanceUID shared by all files in the directory.

    Raises
    ------
    FileNotFoundError
        If the directory does not exist or contains no valid DICOM files.
    ValueError
        If multiple SeriesInstanceUIDs are found (mixed series).
    """
    series_dir = Path(series_dir)
    if not series_dir.is_dir():
        raise FileNotFoundError(f"Series directory not found: {series_dir}")

    uids: set[str] = set()
    for entry in sorted(series_dir.iterdir()):
        if entry.name.startswith(".") or entry.is_dir():
            continue
        ds = _read_dicom_safe(entry)
        if ds is None:
            continue
        uid = getattr(ds, "SeriesInstanceUID", None)
        if uid is not None:
            uids.add(str(uid))
        # Only need one valid file to get the UID — early exit
        if uids:
            break

    if not uids:
        raise FileNotFoundError(
            f"No valid DICOM files with SeriesInstanceUID found in {series_dir}"
        )
    if len(uids) > 1:
        raise ValueError(
            f"Multiple SeriesInstanceUIDs found in {series_dir}: {uids}"
        )

    series_uid = uids.pop()
    logger.info("SeriesInstanceUID: %s", series_uid)
    return series_uid


def extract_seg(
    input_dir: str | Path,
    output_dir: str | Path = "results",
    *,
    series_subdir: str = "original",
) -> Path:
    """
    Given a directory containing a DICOM CT series, look up the matching
    DICOM SEG from the package's bundled registry and copy it to
    *output_dir*.

    The function will:
    1. Read the SeriesInstanceUID from the CT series in
       ``input_dir/<series_subdir>/`` (or directly from *input_dir* if
       it contains DICOM files).
    2. Look up the SeriesInstanceUID in the bundled registry to find the
       pre-packaged DICOM SEG file.
    3. Copy the SEG file into ``output_dir/<patient_id>/output-seg.dcm``.

    Parameters
    ----------
    input_dir : str | Path
        Path to a patient directory or directly to a directory containing
        a DICOM CT series.
    output_dir : str | Path
        Destination directory for the result. Created if it does not exist.
    series_subdir : str
        Name of the subdirectory containing the CT DICOM series
        (default ``"original"``).

    Returns
    -------
    tuple[Path, str | None]
        A tuple of (path to the saved SEG file, exam info text or None).

    Raises
    ------
    FileNotFoundError
        If the series directory is missing or no matching SEG is bundled
        for the given SeriesInstanceUID.
    """
    input_dir = Path(input_dir).resolve()
    output_dir = Path(output_dir).resolve()

    # --- Step 1: Read SeriesInstanceUID from the CT series ----------------
    series_path = input_dir / series_subdir
    if not series_path.is_dir():
        # Fall back: the input_dir itself may contain the DICOM files
        series_path = input_dir
    logger.info("Reading DICOM series from %s", series_path)
    series_uid = read_series_uid(series_path)

    # --- Step 2: Look up in the bundled registry --------------------------
    seg_path = registry.lookup(series_uid)
    if seg_path is None:
        available = registry.list_entries()
        raise FileNotFoundError(
            f"No bundled DICOM SEG for SeriesInstanceUID {series_uid}.\n"
            f"Registered series UIDs ({len(available)}):\n"
            + "\n".join(f"  - {uid}" for uid in available)
        )

    # --- Step 3: Retrieve exam info ---------------------------------------
    info_text = registry.lookup_info(series_uid)

    # --- Step 4: Save to results ------------------------------------------
    patient_id = input_dir.name
    dest_dir = output_dir / patient_id
    dest_dir.mkdir(parents=True, exist_ok=True)
    dest_file = dest_dir / "output-seg.dcm"

    shutil.copy2(str(seg_path), str(dest_file))
    logger.info("SEG saved to %s", dest_file)

    return dest_file, info_text


def extract_seg_batch(
    root_dir: str | Path,
    output_dir: str | Path = "results",
    *,
    series_subdir: str = "original",
) -> list[Path]:
    """
    Process all patient directories under *root_dir*.

    Parameters
    ----------
    root_dir : str | Path
        Root directory containing patient subdirectories.
    output_dir : str | Path
        Destination directory for results.
    series_subdir : str
        Name of the subdirectory containing the CT DICOM series.

    Returns
    -------
    list[tuple[Path, str | None]]
        List of (path to saved SEG file, exam info text or None).
    """
    root_dir = Path(root_dir)
    results: list[tuple[Path, str | None]] = []
    errors: list[str] = []

    for patient_dir in sorted(root_dir.iterdir()):
        if not patient_dir.is_dir() or patient_dir.name.startswith("."):
            continue
        series_path = patient_dir / series_subdir
        if not series_path.is_dir():
            logger.debug(
                "Skipping %s (no '%s' subdir)", patient_dir.name, series_subdir
            )
            continue

        try:
            result, info_text = extract_seg(
                patient_dir, output_dir, series_subdir=series_subdir
            )
            results.append((result, info_text))
            logger.info("OK  %s -> %s", patient_dir.name, result)
        except Exception as exc:
            errors.append(f"{patient_dir.name}: {exc}")
            logger.error("FAIL %s: %s", patient_dir.name, exc)

    if errors:
        logger.warning(
            "%d patient(s) failed:\n  %s", len(errors), "\n  ".join(errors)
        )

    return results
