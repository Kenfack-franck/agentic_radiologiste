"""dcm-seg-nodules: Extract DICOM SEG IOD from a DICOM CT series."""

from dcm_seg_nodules.core import extract_seg

__all__ = ["extract_seg"]
__version__ = "1.0.0"
