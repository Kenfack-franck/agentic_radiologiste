"""Command-line interface for dcm-seg-nodules."""

from __future__ import annotations

import argparse
import logging
import sys

from dcm_seg_nodules.core import extract_seg, extract_seg_batch
from dcm_seg_nodules.registry import ingest, list_entries, lookup_info


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="dcm-seg-nodules",
        description=(
            "Retrieve a bundled DICOM SEG IOD for a given CT series "
            "by matching its SeriesInstanceUID."
        ),
    )
    sub = parser.add_subparsers(dest="command")

    # ---- extract (default behaviour) ------------------------------------
    p_extract = sub.add_parser(
        "extract",
        help="Extract the bundled SEG for one or more CT series.",
    )
    p_extract.add_argument(
        "input",
        help=(
            "Path to a patient directory (single mode) or root directory "
            "containing multiple patient directories (--batch)."
        ),
    )
    p_extract.add_argument(
        "-o", "--output", default="results",
        help="Output directory for extracted SEG files (default: results/).",
    )
    p_extract.add_argument(
        "--series-subdir", default="original",
        help="Subdirectory name holding the CT DICOM series (default: original).",
    )
    p_extract.add_argument(
        "--batch", action="store_true",
        help="Process all patient directories under INPUT.",
    )
    p_extract.add_argument(
        "-v", "--verbose", action="store_true",
        help="Enable verbose (DEBUG) logging.",
    )

    # ---- ingest ---------------------------------------------------------
    p_ingest = sub.add_parser(
        "ingest",
        help="Add a DICOM SEG file to the package's bundled registry.",
    )
    p_ingest.add_argument(
        "seg_file", nargs="+",
        help="Path(s) to DICOM SEG file(s) to ingest.",
    )
    p_ingest.add_argument(
        "--info",
        help="Path to an info.txt file with exam characteristics.",
    )
    p_ingest.add_argument(
        "-v", "--verbose", action="store_true",
        help="Enable verbose (DEBUG) logging.",
    )

    # ---- list -----------------------------------------------------------
    p_list = sub.add_parser(
        "list",
        help="List all registered CT SeriesInstanceUID → SEG mappings.",
    )
    p_list.add_argument(
        "-v", "--verbose", action="store_true",
        help="Enable verbose (DEBUG) logging.",
    )

    args = parser.parse_args(argv)
    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(levelname)s | %(message)s",
    )

    # Default to "extract" when no subcommand and a positional arg is given
    if args.command is None:
        parser.print_help()
        return 0

    try:
        if args.command == "extract":
            if args.batch:
                results = extract_seg_batch(
                    args.input, args.output,
                    series_subdir=args.series_subdir,
                )
                print(f"\nDone. {len(results)} SEG file(s) saved to {args.output}/")
            else:
                result, info_text = extract_seg(
                    args.input, args.output,
                    series_subdir=args.series_subdir,
                )
                print(f"\nSEG saved to {result}")
                if info_text:
                    print("\n" + "=" * 60)
                    print("Exam Characteristics")
                    print("=" * 60)
                    print(info_text)
                    print("=" * 60)

        elif args.command == "ingest":
            for seg_file in args.seg_file:
                uid = ingest(seg_file, info_file=getattr(args, 'info', None))
                print(f"Ingested {seg_file} -> CT SeriesInstanceUID {uid}")

        elif args.command == "list":
            entries = list_entries()
            if not entries:
                print("No SEG files registered.")
            else:
                print(f"{'CT SeriesInstanceUID':<72} {'SEG file':<30} {'Description'}")
                print("-" * 120)
                for uid, info in entries.items():
                    print(f"{uid:<72} {info['seg_file']:<30} {info.get('description', '')}")

    except Exception as exc:
        logging.error("%s", exc)
        return 1

    return 0


if __name__ == "__main__":
    sys.exit(main())
